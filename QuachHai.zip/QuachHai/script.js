// Hiển thị thông báo khi nhấp vào nút liên hệ
const contactButton = document.querySelector('#contact-button');

contactButton.addEventListener('click', () => {
  alert('Bạn đã nhấp vào nút liên hệ!');
});
const fish = document.getElementById('fish');
const colors = ['blue', 'red', 'green', 'orange', 'purple'];
let currentColor = 0;

setInterval(() => {
  currentColor = (currentColor + 1) % colors.length;
  fish.style.background = colors[currentColor];
}, 1000);

